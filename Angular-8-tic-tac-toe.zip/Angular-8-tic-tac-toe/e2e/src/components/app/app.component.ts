import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tic-tac-toe-angular';
  dimension = 0;

onchange($event: { target: { value: string; }; }): any {
    // tslint:disable-next-line: radix
    this.dimension = parseInt($event.target.value);
  }
}
