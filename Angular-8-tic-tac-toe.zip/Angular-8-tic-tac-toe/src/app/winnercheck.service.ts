import { AppComponent } from './app.component';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WinnercheckService {

  constructor(
    private winnerCheckService: WinnercheckService) { }
  dimension = 3;
  board = Array(9).fill(null);
  xTurn = true;  // Initialized  X as Current player
  addSymbol(id: number) {
    if (this.board[id]) { return; }
    this.board[id] = (this.xTurn ? 'X' : 'O') ;
    this.xTurn = !this.xTurn;
  }

  indexFinder(board: Array<string>) {
    const xIndex = [];
    const oIndex = [];
    board.map(
      (item, index) => {
        const InitVoid = item === 'X' ? xIndex.push([Math.floor(index / this.dimension), (index % this.dimension)])
          : (item === 'O' ? oIndex.push([Math.floor(index / this.dimension), index % this.dimension])
            : void (0));
      });
    return [xIndex, oIndex];
  }

  checkX(board: Array<string>): any[] {
    const xIndex = this.indexFinder(board)[0];
    const xRow: any[] = Array(this.dimension).fill(0);
    const xColumn: any[] = Array(this.dimension).fill(0);
    const xMainDiagram: number = xIndex.filter((item) => item[0] === item[1]).length;
    let xSubDiagram = 0;
    let currentDimension = this.dimension;
    xIndex.forEach(item => { xRow[item[0]]++; xColumn[item[1]]++; });
    for (let iteration = 0; iteration <= this.dimension; iteration++) {
      xIndex.forEach(item => {
        const newLocal = item[0] === iteration && item[1] === (currentDimension - 1) && (xSubDiagram++);
      });
      currentDimension--;
    }
    return [xColumn, xRow, xMainDiagram, xSubDiagram];
  }

  checkO(board: Array<string>): any[] {
    const oIndex = this.indexFinder(board)[1];
    const oRow: any[] = Array(this.dimension).fill(0);
    const oColumn: any[] = Array(this.dimension).fill(0);
    const oMainDiagram: number = oIndex.filter((item) => item[0] === item[1]).length;
    let oSubDiagram = 0;
    let currentDimension = this.dimension;
    oIndex.forEach((item) => { oRow[item[0]]++; oColumn[item[1]]++; });
    for (let iteration = 0; iteration <= this.dimension; iteration++) {
      oIndex.forEach(item => {
        const newLocal = item[0] === iteration && item[1] === (currentDimension - 1) && (oSubDiagram++);
      });
      currentDimension--;
    }
    return [oColumn, oRow, oMainDiagram, oSubDiagram];
  }

  makeDias(board: Array<string>) {
    const xSubDiag = this.checkX(board)[3];
    const xMainDiag = this.checkX(board)[2];
    const oSubDiag = this.checkO(board)[3];
    const oMainDia = this.checkO(board)[2];
    return [xMainDiag, oMainDia, xSubDiag, oSubDiag];
  }

  checkWinner(board: Array<string>) {
    const xIndex = this.indexFinder(board)[0];
    const oIndex = this.indexFinder(board)[1];
    const xRow = this.checkX(board)[1];
    const oRow = this.checkO(board)[1];
    const oColumn = this.checkO(board)[0];
    const xColumn = this.checkX(board)[0];

    let winner = [];
    const indexes = [];

    oRow.filter((item: number, index: any): any => {if (item === 3) { winner = ['O' , 'row', index]; }});
    oColumn.filter((item: number, index: any) => {if (item === 3) { winner = ['O', 'column', index]; }});
    xRow.filter((item: number, index: any) => {if (item === 3) { winner = ['X', 'row', index]; }});
    xColumn.filter((item: number, index: any) => {if (item === 3) { winner = ['X', 'column', index]; }});

    const Dias = this.makeDias(board);
    if (Dias[0] === 3) { winner = ['X', 'Main']; }
    if (Dias[2] === 3) { winner = ['X', 'Sub']; }
    if (Dias[1] === 3) { winner = ['O', 'Main']; }
    if (Dias[3] === 3) { winner = ['O', 'Sub']; }

    if (xIndex.length + oIndex.length === 9) { winner = ['Draw']; }

    if (winner.length === 3) {
      winner[1] === 'row' ? indexes.push([winner[2] * this.dimension, (winner[2] * this.dimension) + 1, (winner[2] * this.dimension) + 2])
        : indexes.push([winner[2], winner[2] + this.dimension, winner[2] + (2 * this.dimension)]);
      return indexes[0];
    } else if (winner.length === 2) {
      winner[1] === 'Main' ? indexes.push([0, this.dimension + 1, 2 * (this.dimension + 1)])
        : indexes.push([this.dimension - 1, (this.dimension - 1) * 2, (this.dimension - 1) * 3]);
      return indexes[0];
    }
    return indexes;
  }
}
